# FivePlay — iPhone 13 tuned unsigned IPA

WebView shell for **https://fiveplay.lol** (GrandV browser GTA V), tuned for **iPhone 13** (A15 / 4 GB).

## What changed for iPhone 13

- Screen keep-awake while the game is open
- Desktop content mode (better WebGL path on many ports)
- Soft canvas cap ~1280×720 to limit GPU load
- Best-effort low-graphics localStorage nudges
- Process-kill recovery (common under WASM on 4 GB)
- Landscape + portrait, status bar / home indicator hidden
- Touch-friendly CSS for on-screen controls
- App-bound domains: fiveplay.lol + v2.fiveplay.lol

## Build unsigned IPA (GitHub Actions)

1. Push this folder to a **public** GitHub repo `main`
2. Actions → **Build IPA** → Run workflow
3. Download artifact `FivePlay-unsigned.ipa`
4. Import into **KSign** → Sign → Install

## Play tips on iPhone 13

- Wi-Fi + charger recommended (first load is large)
- Close other apps before launching
- If white screen after multitasking: force-quit FivePlay and reopen (shell also auto-reloads)
- In-game: pick the lowest graphics / performance preset if the UI offers one

Version: 1.1
