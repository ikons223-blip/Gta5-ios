import UIKit
import WebKit

/// FivePlay / GrandV shell tuned for iPhone 13-class devices (A15, 4 GB).
/// Goal: keep the WASM/WebGL GTA port alive, prefer playable FPS over max fidelity.
final class WebViewController: UIViewController {

    // Game entry — direct play URL
    private static let homeURL = URL(string: "https://fiveplay.lol")!

    private var webView: WKWebView!
    private var themeObservation: NSKeyValueObservation?
    private var statusBarStyle: UIStatusBarStyle = .lightContent

    // MARK: - Lifecycle

    override var prefersStatusBarHidden: Bool { true }
    override var preferredStatusBarStyle: UIStatusBarStyle { statusBarStyle }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var preferredScreenEdgesDeferringSystemGestures: UIRectEdge { .all }

    override func loadView() {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        // Service Worker + app-bound domains (Info.plist WKAppBoundDomains)
        config.limitsNavigationsToAppBoundDomains = true
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.javaScriptCanOpenWindowsAutomatically = true

        if #available(iOS 15.0, *) {
            config.preferences.isElementFullscreenEnabled = true
        }

        // Desktop content mode — many browser game ports gate WebGL features on desktop UA
        let pagePrefs = WKWebpagePreferences()
        pagePrefs.allowsContentJavaScript = true
        pagePrefs.preferredContentMode = .desktop
        config.defaultWebpagePreferences = pagePrefs

        let ver = (Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "1.0"
        config.applicationNameForUserAgent = "FivePlay/\(ver) (iPhone13; playable)"

        let ucc = WKUserContentController()
        ucc.addUserScript(WKUserScript(
            source: Self.shellBootstrapJS(version: ver),
            injectionTime: .atDocumentStart,
            forMainFrameOnly: true))
        ucc.addUserScript(WKUserScript(
            source: Self.performanceTuneJS,
            injectionTime: .atDocumentEnd,
            forMainFrameOnly: true))
        config.userContentController = ucc

        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsLinkPreview = false
        webView.allowsBackForwardNavigationGestures = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.bounces = false
        webView.scrollView.isScrollEnabled = true
        webView.scrollView.showsVerticalScrollIndicator = false
        webView.scrollView.showsHorizontalScrollIndicator = false
        webView.scrollView.delaysContentTouches = false
        webView.scrollView.canCancelContentTouches = true
        webView.isOpaque = true
        webView.backgroundColor = .black
        webView.scrollView.backgroundColor = .black
        webView.underPageBackgroundColor = .black

        if #available(iOS 16.4, *) {
            webView.isInspectable = false
        }

        let root = UIView()
        root.backgroundColor = .black
        root.addSubview(webView)
        webView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: root.topAnchor),
            webView.bottomAnchor.constraint(equalTo: root.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: root.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: root.trailingAnchor),
        ])
        view = root
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Keep screen on while the game is open — critical for long sessions
        UIApplication.shared.isIdleTimerDisabled = true
        observeThemeColor()
        loadHome()
        NotificationCenter.default.addObserver(
            self, selector: #selector(appDidBecomeActive),
            name: UIApplication.didBecomeActiveNotification, object: nil)
        NotificationCenter.default.addObserver(
            self, selector: #selector(appWillResign),
            name: UIApplication.willResignActiveNotification, object: nil)
    }

    deinit {
        UIApplication.shared.isIdleTimerDisabled = false
    }

    // MARK: - Load / recover

    private func loadHome() {
        var req = URLRequest(url: Self.homeURL)
        req.cachePolicy = .useProtocolCachePolicy
        webView.load(req)
    }

    @objc private func appDidBecomeActive() {
        UIApplication.shared.isIdleTimerDisabled = true
        // WebKit content process can be killed in background → white screen
        if webView.url == nil {
            loadHome()
        } else {
            webView.evaluateJavaScript(Self.performanceTuneJS, completionHandler: nil)
        }
    }

    @objc private func appWillResign() {
        // Allow system sleep when leaving the app
        UIApplication.shared.isIdleTimerDisabled = false
    }

    // MARK: - Theme

    private func observeThemeColor() {
        themeObservation = webView.observe(\.themeColor, options: [.new]) { [weak self] wv, _ in
            self?.applyThemeColor(wv.themeColor)
        }
    }

    private func applyThemeColor(_ color: UIColor?) {
        let c = color ?? .black
        webView.underPageBackgroundColor = c
        view.backgroundColor = c
        statusBarStyle = .lightContent
        setNeedsStatusBarAppearanceUpdate()
    }

    // MARK: - Injected scripts

    private static func shellBootstrapJS(version: String) -> String {
        """
        window.__NATIVE_SHELL__ = true;
        window.__SHELL_VER__ = '\(version)';
        window.__SHELL_DEVICE__ = 'iPhone13';
        window.__SHELL_TARGET__ = 'playable';
        try {
          var m = document.querySelector('meta[name="viewport"]');
          if (!m) {
            m = document.createElement('meta');
            m.name = 'viewport';
            (document.head || document.documentElement).appendChild(m);
          }
          var c = m.getAttribute('content') || 'width=device-width, initial-scale=1';
          if (c.indexOf('viewport-fit') === -1) c += ', viewport-fit=cover';
          if (c.indexOf('maximum-scale') === -1) c += ', maximum-scale=1, user-scalable=no';
          m.setAttribute('content', c);
        } catch (e) {}
        """
    }

    /// Best-effort low / mobile-friendly defaults for browser GTA ports.
    /// Does not break the site if keys differ — only nudges known patterns.
    private static let performanceTuneJS: String = #"""
    (function () {
      try {
        // Prefer low graphics presets if the port stores them in localStorage
        var keys = [
          'graphics', 'quality', 'gfx', 'settings', 'graphicsQuality',
          'grandv_graphics', 'fiveplay_graphics', 'renderScale', 'lodscale',
          'density', 'postfx', 'motionblur', 'dof', 'ssao'
        ];
        var lowMap = {
          graphics: 'low', quality: 'low', gfx: 'low', graphicsQuality: 'low',
          grandv_graphics: 'low', fiveplay_graphics: 'low',
          renderScale: '0.7', lodscale: '0.6', density: 'low',
          postfx: '0', motionblur: '0', dof: '0', ssao: '0'
        };
        for (var i = 0; i < keys.length; i++) {
          var k = keys[i];
          try {
            if (localStorage.getItem(k) == null && lowMap[k] != null) {
              localStorage.setItem(k, lowMap[k]);
            }
          } catch (e) {}
        }

        // Soft-cap canvas resolution on small high-DPI phones (iPhone 13 logical ~390pt)
        var cap = function () {
          try {
            var cvs = document.querySelectorAll('canvas');
            for (var i = 0; i < cvs.length; i++) {
              var c = cvs[i];
              if (!c || c.__fiveplayCapped) continue;
              var w = c.width, h = c.height;
              if (w > 1280 || h > 720) {
                var s = Math.min(1280 / w, 720 / h, 1);
                if (s < 1) {
                  c.width = Math.floor(w * s);
                  c.height = Math.floor(h * s);
                  c.style.width = '100%';
                  c.style.height = '100%';
                }
              }
              c.__fiveplayCapped = true;
            }
          } catch (e) {}
        };
        cap();
        setInterval(cap, 4000);

        // Fun micro-nudge: slight CSS for touch targets if on-screen controls exist
        var st = document.createElement('style');
        st.id = 'fiveplay-shell-touch';
        st.textContent = [
          'html,body{background:#000!important;overscroll-behavior:none;}',
          'canvas{touch-action:none;}',
          'button, [role=button], .btn, .control, .touch-btn {',
          '  min-height:44px; min-width:44px;',
          '}'
        ].join('');
        (document.head || document.documentElement).appendChild(st);
      } catch (e) {}
    })();
    """#
}

// MARK: - Navigation

extension WebViewController: WKNavigationDelegate {

    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.allow); return
        }
        let host = (url.host ?? "").lowercased()
        let scheme = (url.scheme ?? "").lowercased()
        let allowedHosts: Set<String> = [
            "fiveplay.lol", "www.fiveplay.lol",
            "v2.fiveplay.lol", "cdn.fiveplay.lol"
        ]
        let inApp = allowedHosts.contains(host)
            || host.hasSuffix(".fiveplay.lol")
            || ["data", "blob", "about"].contains(scheme)
        if inApp {
            decisionHandler(.allow)
        } else {
            decisionHandler(.cancel)
            if scheme == "http" || scheme == "https" {
                UIApplication.shared.open(url)
            }
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        applyThemeColor(webView.themeColor)
        webView.evaluateJavaScript(Self.performanceTuneJS, completionHandler: nil)
    }

    func webView(_ webView: WKWebView,
                 didFail navigation: WKNavigation!,
                 withError error: Error) {
        // Soft retry once on network blip
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [weak self] in
            self?.loadHome()
        }
    }

    func webView(_ webView: WKWebView,
                 didFailProvisionalNavigation navigation: WKNavigation!,
                 withError error: Error) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [weak self] in
            self?.loadHome()
        }
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        // Common on 4 GB devices under WASM pressure — reload clean
        loadHome()
    }
}

// MARK: - UI / popups

extension WebViewController: WKUIDelegate {

    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil, let url = navigationAction.request.url {
            let host = (url.host ?? "").lowercased()
            if host.contains("fiveplay.lol") || ["data", "blob", "about"].contains(url.scheme ?? "") {
                webView.load(navigationAction.request)
            } else {
                UIApplication.shared.open(url)
            }
        }
        return nil
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping () -> Void) {
        let ac = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        present(ac, animated: true)
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (Bool) -> Void) {
        let ac = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(false) })
        ac.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        present(ac, animated: true)
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptTextInputPanelWithPrompt prompt: String,
                 defaultText: String?,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (String?) -> Void) {
        let ac = UIAlertController(title: nil, message: prompt, preferredStyle: .alert)
        ac.addTextField { $0.text = defaultText }
        ac.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(nil) })
        ac.addAction(UIAlertAction(title: "OK", style: .default) { _ in
            completionHandler(ac.textFields?.first?.text)
        })
        present(ac, animated: true)
    }
}
